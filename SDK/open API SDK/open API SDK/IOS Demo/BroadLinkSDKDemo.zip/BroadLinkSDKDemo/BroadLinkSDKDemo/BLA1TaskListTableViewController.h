//
//  BLA1TaskListTableViewController.h
//  BroadLinkSDKDemo
//
//  Created by yzm157 on 14-6-6.
//  Copyright (c) 2014年 BroadLink. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BLDeviceInfo.h"

@interface BLA1TaskListTableViewController : UITableViewController

@property (nonatomic, strong) BLDeviceInfo *info;

@end
