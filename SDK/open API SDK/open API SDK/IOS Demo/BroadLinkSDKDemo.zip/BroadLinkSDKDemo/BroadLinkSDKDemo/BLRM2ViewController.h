//
//  BLRM2ViewController.h
//  BroadLinkSDKDemo
//
//  Created by yzm157 on 14-5-28.
//  Copyright (c) 2014年 BroadLink. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BLDeviceInfo.h"

@interface BLRM2ViewController : UIViewController

@property (nonatomic, strong) BLDeviceInfo *info;

@end
