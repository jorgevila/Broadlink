//
//  BLEasyConfigViewController.h
//  BroadLinkSDKDemo
//
//  Created by yzm157 on 14-5-28.
//  Copyright (c) 2014年 BroadLink. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BLEasyConfigViewController : UIViewController

@end
